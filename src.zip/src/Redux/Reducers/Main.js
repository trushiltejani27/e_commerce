import { combineReducers } from "redux";
import { cartreducer } from "./Reducers";


const rootred = combineReducers({
  cartreducer
});

export default rootred